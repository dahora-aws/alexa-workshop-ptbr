# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: LicenseRef-.amazon.com.-AmznSL-1.0
# Licensed under the Amazon Software License http://aws.amazon.com/asl/

import json
import random
import datetime
import pytz

CELEBS = []
MONTHS = {"janeiro": 1, "fevereiro": 2, "março": 3, "abril": 4, "maio": 5, "junho": 6, "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12}

with open("./documents/birthday.json") as birthday_doc:
    CELEBS = json.load(birthday_doc)

def get_random_celeb(past_celebs = []):

    remaining = [d for d in CELEBS if d not in past_celebs]

    if len(remaining) > 0:
        random.shuffle(remaining)
        return remaining[0]
    else:
        return {
            "id": 0,
            "name": None,
            "birthday": None
        }

def check_answer(current_celeb, month, year):
    if len(year)==2:
        year = 1900 + int(year)
    d = datetime.datetime.strptime(current_celeb["birthday"], '%Y-%m-%d')
    return d.month == MONTHS[month.lower()] and d.year == int(year)

def get_hour(user_time_zone):
    d = datetime.datetime.now(pytz.timezone(user_time_zone))
    return d.hour